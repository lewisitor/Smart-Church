# Smart-Church
Full Gospel mission local church financial system to save and produce statistics and submission form automatically
